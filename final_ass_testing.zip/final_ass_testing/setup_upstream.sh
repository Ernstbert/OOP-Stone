#!/bin/bash

git remote add upstream git@gitlab.tugraz.at:oop1-2020/assignment.git
echo DONE
