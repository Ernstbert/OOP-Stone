#!/bin/bash

git pull upstream master
echo DONE
